
<?php $__env->startSection("title", "Error"); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-center">
            <p class="h1 text-center">Error<br>Producto No Encontrado</p>
        </div>
        <div class="d-flex justify-content-center">
            <button type="button" class="btn btn-link" onclick="history.back()">Regresar</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Xipearte-E-Commerce\resources\views/error_views/product_not_found.blade.php ENDPATH**/ ?>