<div class="py-3">
    <hr />
</div>
<?php /**PATH C:\laragon\www\Xipearte-E-Commerce\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>