<a class="d-flex justify-content-center mb-4" href="/">
    <img src="<?php echo e(asset('assets/logo.jpeg')); ?>" alt="logo_xipearte" class="img-fluid" style="width: 100px"/>
</a>
<?php /**PATH C:\laragon\www\Xipearte-E-Commerce\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>